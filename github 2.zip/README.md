# MS FIXER Management — Integrated Build

This build combines the existing Supabase-authenticated MS FIXER Management dashboard with the browser-local MS FIXER POS module.

## Main app
- Owner sign-in through Supabase Auth
- Existing Supabase-backed modules and data forms
- Product, customer, supplier, sales, purchase, inventory, accounts, payments, service, warranty, branches, employees and expenses modules
- Integrated POS & Invoice page, opened after signing into the main app

## POS module
- Dashboard, product and stock management, categories and brands
- POS sales, cart, customer details, discounts, paid/due
- PDF invoice download/print/share where supported
- Customers, suppliers, purchases, due collection and supplier payments
- Expenses, staff/salary, accounts and transfers
- Stock adjustment, sales history, reports, settings
- JSON backup/restore and PWA assets

## Important data and security limitations
- The main management app uses Supabase Auth and Supabase database tables.
- **The integrated POS module currently stores its own records in this browser's Local Storage. It is NOT synced to Supabase and will NOT automatically appear on another device.**
- POS data and main-app Supabase data are separate stores; do not assume stock, sales, customers or accounts are shared between them.
- POS module has no separate login; it is intended to be opened from the authenticated main app. Do not publish the `pos/` folder as a standalone public app if you require access control.
- This build does not yet implement POS-to-Supabase synchronization, transactional stock updates across both modules, multi-user concurrency, role-based permissions, or a full audit log.
- Keep JSON backups of POS data. Browser data can be lost if site data is cleared.
- Supabase Row Level Security policies and table schemas must be correctly configured in the Supabase project. A publishable key is not a substitute for RLS.
- Test with dummy records before using live business data.

## Deploy
Upload the contents of this ZIP to the same static hosting project / Cloudflare Worker asset deployment used by the current app. Keep the directory structure, especially `pos/` and `pos/assets/`.
