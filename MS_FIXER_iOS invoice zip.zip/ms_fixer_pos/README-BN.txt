MS FIXER POS — Version 2.0 (Browser-local release)

এই প্যাকেজে যা কাজ করে
----------------------
1. Dashboard: বিক্রি, Gross Profit, খরচ, Net Profit, মোট স্টক, Customer Due, Supplier Due এবং অ্যাকাউন্ট ব্যালেন্স।
2. Products: পণ্যের নাম, কোড, ক্যাটাগরি, ব্র্যান্ড, মডেল, IMEI/Serial, স্টক, ক্রয়মূল্য, বিক্রয়মূল্য, Low Stock Alert এবং ছবি যোগ/এডিট।
3. POS: নাম/কোড দিয়ে পণ্য খোঁজা, কার্টে পণ্যের ছবি দেখা, পরিমাণ/স্টক যাচাই, Walking Customer-এর নাম/মোবাইল/ঠিকানা, Discount, Paid এবং Due।
4. Invoice: দোকানের নাম/ঠিকানা/মোবাইল/লোগো, কাস্টমার তথ্য, পণ্যের নাম (ছবি নয়), Qty, Price, Total, Paid, Due এবং Customer/Seller Signature।
5. Invoice PDF: বাস্তব PDF ফাইল তৈরি, Download, এবং সমর্থিত মোবাইল ব্রাউজারে Share PDF; Share API না থাকলে Download করে অন্য অ্যাপ থেকে শেয়ার করুন। Print-ও আছে।
6. Customers ও Suppliers: নাম, মোবাইল, ঠিকানা।
7. Purchases: সাপ্লায়ার, পণ্য, পরিমাণ, ক্রয়মূল্য, Paid ও Due; স্টক বাড়ে এবং অ্যাকাউন্ট থেকে Paid টাকা কমে।
8. Due Collection: কাস্টমারের বাকি আদায়; বিক্রির বাকি কমে এবং নির্বাচিত অ্যাকাউন্টে টাকা যোগ হয়।
9. Supplier Payment: সাপ্লায়ারের বাকি পরিশোধ; ক্রয়ের বাকি কমে এবং অ্যাকাউন্ট থেকে টাকা কমে।
10. Expenses এবং Employee/Salary।
11. Accounts: Cash, Bank, bKash, Nagad সহ নিজের অ্যাকাউন্ট যোগ, Opening Balance এবং এক অ্যাকাউন্ট থেকে অন্য অ্যাকাউন্টে হিসাবি Transfer।
12. Stock Adjustment: স্টক বাড়ানো/কমানোর রেকর্ড।
13. Sales History, Reports, Admin Settings।
14. JSON Backup Download এবং Backup Restore।
15. PWA manifest, MS FIXER logo app icon, এবং static app shell-এর offline cache।

প্রথমবার ব্যবহার
----------------
1. ZIP Extract করুন।
2. ms_fixer_pos ফোল্ডারের ভেতরের সব ফাইল Netlify-তে Deploy করুন।
3. HTTPS URL খুলুন। Admin Settings-এ নিজের দোকানের নাম, ঠিকানা, মোবাইল, লোগো ও currency দিন।
4. Products, Categories, Brands, Customers, Suppliers এবং Accounts সেট করুন।
5. Accounts-এ সঠিক Opening Balance না দিলে Cash/Bank/Wallet হিসাব বাস্তবের সঙ্গে মিলবে না।
6. নিয়মিত Backup বোতাম থেকে JSON ফাইল ডাউনলোড করে Google Drive-এ নিজে আপলোড করে রাখুন।
7. Chrome/Safari-এর Add to Home Screen / Install App ব্যবহার করুন।

অত্যন্ত গুরুত্বপূর্ণ সীমাবদ্ধতা — বাস্তব দোকানের ডাটা দেওয়ার আগে পড়ুন
------------------------------------------------------------------
• এই সংস্করণে ডাটা যে ব্রাউজার/ডিভাইসে এন্ট্রি করবেন, সেই ব্রাউজারের Local Storage-এ থাকে। অন্য ফোন/কম্পিউটারে নিজে নিজে Sync হবে না।
• Google Drive/Gmail-এ Automatic Backup বা Google Login এই সংস্করণে যুক্ত নেই। আপাতত JSON Backup Download করে নিজে Drive-এ রাখুন।
• Netlify শুধু ওয়েবসাইট হোস্ট করে; নিজে থেকে Database, Login, Cloud Sync বা নিরাপদ Multi-user ব্যবস্থা দেয় না। এগুলোর জন্য Supabase/Firebase-এর মতো Backend, Authentication, Database Rules এবং আলাদা Configuration প্রয়োজন।
• Accounts-এর Transfer হলো সফটওয়্যারের হিসাবি Transfer; এটি bKash/ব্যাংকে আসল টাকা পাঠায় না। কোনো ব্যাংক বা Mobile Banking API যুক্ত নেই।
• bKash/Nagad ব্যালেন্স অ্যাপে ম্যানুয়ালি রেকর্ড করতে হবে; সরাসরি সংযোগ নেই।
• IMEI/Serial বর্তমানে পণ্যের রেকর্ডে একটি ফিল্ড; প্রতিটি ইউনিটের আলাদা Serial-wise tracking এখনো নেই।
• Sales Return/Refund, Purchase Return, VAT/Tax, Role-based Staff Login এবং পূর্ণাঙ্গ Audit Log এই সংস্করণে নেই।
• PDF এক পৃষ্ঠার A4 layout। অনেক বেশি line item থাকলে পরের সংস্করণে multi-page pagination যোগ করা দরকার।
• Browser data clear, app reset বা ডিভাইস নষ্ট হলে Local Storage-এর ডাটা হারাতে পারেন। নিয়মিত JSON Backup ছাড়া ব্যবহার করবেন না।

ব্যবসার আসল হিসাব চালুর আগে নিজের কিছু Test Product/Customer দিয়ে কয়েক দিন পরীক্ষা করুন। Cloud database, Google Drive backup এবং multi-device sync যুক্ত ও পরীক্ষা না হওয়া পর্যন্ত এটিকে production-grade cloud POS মনে করবেন না।
