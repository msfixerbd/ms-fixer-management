# MS FIXER POS — Netlify package

## Important status
This is a functional first-release browser POS package with local browser storage. It includes product/category/brand management, customers/suppliers, purchases, sales, invoice print / browser Save-as-PDF, staff salary, expenses, cash/bank/mobile-wallet accounts, transfers, sales history, reports, settings, and JSON backup/restore.

**Cloud sync is not enabled in this ZIP.** Netlify static hosting alone does not synchronize data between iPhone and computer. A Supabase project (or another backend), authentication, database policies, and configuration are required. Do not enter real business data until you have a tested cloud backend and backup process. Browser-local data can be lost if browser storage is cleared.

## Deploy
1. Extract this ZIP.
2. Upload the contents of the `ms_fixer_pos` folder to Netlify (not the ZIP itself, unless using Netlify's supported deploy flow).
3. Open the deployed HTTPS URL.
4. In Chrome/Safari use Add to Home Screen / Install App.

## First setup
Open Admin Settings and enter shop name, address, mobile number, currency and logo. The supplied MS FIXER logo is included as the starting app icon.

## Invoice PDF
Open Sales History > Open Invoice > Print / Save as PDF. In the print dialog choose Save as PDF. A browser share button is provided, but direct PDF-file sharing depends on browser/device support; this first release shares invoice details, not a generated PDF attachment.

## Testing notes / limitations
- Test on a copy of data first.
- Invoice print layout targets A4; actual printer margins vary.
- This release does not yet implement cloud sync/auth, customer due collection, supplier due settlement, returns/refunds, stock adjustment, daily closing, employee role permissions, Gmail/Google Drive backup, or true PDF-file share. These must be added and tested before this can be considered a complete production POS.
- Product photo is stored in browser local storage; it appears in inventory only, not on invoice.
- Product search is currently a selector; customer details are saved to invoice when selected.
